/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payroll.system;

/**
 *
 * @author JRMA
 */
public class Employee {
    private String name;
    private int salary;
    private int empID;
    private int overtimeHours;
    private int overtimePay;
    private int transpoPay;
    // Employee Builder
    public Employee(String n, int s, int e, int o)
    {
        name = n;
        salary = s;
        empID = e;
        overtimeHours = o;
    }
    public String getName()
    {
        return name;
    }
    public int getSal()
    {
        return salary;
    }
    public int getEmpID()
    {
        return empID;
    }
    public void work()
    {
        System.out.println("I am an employee!");
    }
    public int getOPay()
    {
        return 0;
    }
    public int getTPay()
    {
        return 0;
    }
    public int getOHours()
    {
        return overtimeHours;
    }
    public void setOPay(int n)
    {
        overtimePay = n;
    }
    public void setOHours(int n)
    {
        overtimeHours = n;
    }
    public void setTPay(int n)
    {
        transpoPay = n;
    }
    
}