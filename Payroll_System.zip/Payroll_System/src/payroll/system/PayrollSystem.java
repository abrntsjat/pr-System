/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payroll.system;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author JRMA
 */
public class PayrollSystem{ 
   static Scanner sc = new Scanner(System.in);
    public static void enter(ArrayList <Employee> employees, int n)
    {
        for(int i=0; i < n; i++)
        {
            String name;
            int occ,sal,overH, id;
            System.out.println("Please Enter Employee's Info");
            System.out.println("----------------------------");
            System.out.println("Enter Employees Occupation: ");
            System.out.println("1.) Doctor");
            System.out.println("2.) Engineer");
            System.out.println("3.) Architect");
            System.out.println("4.) Programmer");
            occ = sc.nextInt();
            System.out.print("Enter Employee's ID: ");
            id = sc.nextInt();
            System.out.print("Enter Employee's Name: ");
            sc.next();
            name = sc.nextLine();
            System.out.print("Enter Employee's Salary: ");
            sal = sc.nextInt();
            System.out.print("Enter Employee's Hours Overtime Per-week (max 48): ");
            overH = sc.nextInt();
            
            switch(occ)
            {
                case 1: employees.add(new Doctor(name,sal, id,overH));      break;
                case 2: employees.add(new Engineer(name,sal, id,overH));    break;
                case 3: employees.add(new Architect(name,sal, id,overH));   break;
                case 4: employees.add(new Programmer(name,sal, id,overH));  break;
            }
            System.out.println();
            System.out.println("Successfully added! Num. of Employees = " + employees.size());
            System.out.println();
        }
    }
    public static void edit(Employee emp)
    {
        // ikaw na bahala dito
    }
    public static Employee find(ArrayList <Employee> e, int n)
    {
        for(int i=0; i < e.size(); i++)
        {
            if(n == e.get(i).getEmpID())
            {
                return e.get(i);
            }
        }
        System.out.println("no employee matches with ID " + n);
        return null;
    }
    public static void calculate(Employee emp)
    {
        int total;
        System.out.println("Name: " + emp.getName());
        emp.work();
        System.out.println("Basic Salary: " + emp.getSal());
        System.out.println("Overtime Pay: " + (emp.getOPay() * emp.getOHours()));
        System.out.println("Transportation Fee: " + emp.getTPay());
        total = emp.getSal() + (emp.getOPay() * emp.getOHours()) + emp.getTPay();
        System.out.println("TOTAL: " + total);
        System.out.println("----------------------------");
    }
    public static void main(String[] args) 
    {
        int choice, numEmp;
        Employee emp;
        ArrayList <Employee> employees = new ArrayList <Employee>();
        while(true)
        {
            System.out.println("       --- EMPLOYEES PAY ---       ");
            System.out.println("1.) Enter Employees Info ");
            System.out.println("2.) Edit Employee's Pay Info ");
            System.out.println("3.) Calculate and Display Employee's Pay");
            System.out.println("4.) Calculate and Display All Employees' Pay");
            System.out.println("5.) Exit ");
            System.out.println("***************************************");
            System.out.print("Choose (1-4): ");
            choice = sc.nextInt();
            switch(choice)
            {
                case 1:
                    System.out.print("How many employees: ");
                    numEmp = sc.nextInt();
                    enter(employees, numEmp);
                    break;
                case 2:
                    System.out.print("Enter Employee ID");
                    numEmp = sc.nextInt();
                    emp = find(employees, numEmp);
                    if( emp != null)
                        edit(emp);    
                    break;
                case 3:
                    System.out.print("Enter Employee ID");
                    numEmp = sc.nextInt();
                    emp = find(employees, numEmp);
                    if( emp != null)
                        calculate(emp);
                    break;
                case 4:
                    for(int i=0; i < employees.size(); i++)
                    {
                        System.out.println("Employee #" + (i+1));
                        calculate(employees.get(i));
                    }
                    break;
                case 5:
                    System.out.println("Thank you for using __________");
                    System.exit(0);
            }
        }
    }
}

