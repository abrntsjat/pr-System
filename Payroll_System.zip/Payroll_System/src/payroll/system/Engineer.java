/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package payroll.system;

/**
 *
 * @author JRMA
 */
public class Engineer extends Employee{
    public Engineer(String n, int s, int e, int o)
    {
       super(n,s,e,o);
       super.setOPay((int)(s * 0.020));
       super.setTPay((int)(s * 0.1));
    }
    public void work()
    {
        System.out.print("I build Buildings");
    }
}